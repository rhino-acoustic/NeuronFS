# 🧠 NeuronFS Brain Index

Generated: 2026-04-12T21:18:44 | Neurons: 420/420 | Activation: 9121

## 🕸️ Axon 연결
- 🛡️ brainstem → 🧠 cortex
- 🛡️ brainstem → 📝 hippocampus
- 💓 limbic → 🛡️ brainstem
- 📝 hippocampus → 🛡️ brainstem
- 📝 hippocampus → 🧠 cortex
- 👁️ sensors → 🛡️ brainstem
- 🧠 cortex → 🛡️ brainstem
- 🧠 cortex → 🎭 ego
- 🧠 cortex → 📝 hippocampus
- 🧠 cortex → 💓 limbic
- 🧠 cortex → 🎯 prefrontal
- 🎭 ego → 🧠 cortex
- 🎯 prefrontal → 🧠 cortex

## 🏆 TOP 10 뉴런
1. 🧠 **dev > 추천: > 로컬깃활용** (2068)
2. 🧠 **dev** (1607)
3. 🧠 **methodology > 추천: left-side네비게이션** (375)
4. 🧠 **dev > 추천: > 사이드바구현** (292)
5. 🛡️ **절대 금지: > 중복작업** (211)
6. 🧠 **dev > 좌측네비게이터구현** (209)
7. 🧠 **methodology > 추천: 프로젝트관리** (207)
8. 🛡️ **절대 금지: > 빌드후 미검증재시작** (200)
9. 🛡️ **절대 금지: > 리팩토링 기능누락** (200)
10. 👁️ **이벤트 > 장소검토** (200)

<details>
<summary>🆕 신규 (probation) — 38 neurons (7d window)</summary>

### 🛡️ brainstem (3)
- **절대 금지: > 수동적변경** (4) — 5d남음
- **절대 금지: 뇌 직접수정 MCP필수** (1) — 6d남음
- **반드시 > 반드시 빌드경로 SSOT** (0) — 7d남음

### 💓 limbic (0)
(없음)

### 📝 hippocampus (1)
- **에러 패턴 > 서버오케스트레이터에러** (4) — 4d남음

### 👁️ sensors (4)
- **이벤트 > 장소검토의중요성** (4) — 2d남음
- **이벤트 > 장소검색시교통접근성考慮** (3) — 2d남음
- **환경 > Supabase EdgeFunctions** (3) — 3d남음
- **이벤트 > 장소확정기한** (3) — 2d남음

### 🧠 cortex (27)
- **methodology > CHAT ID영속화** (4) — 5d남음
- **dev > 추천: > 명령어최적화** (4) — 4d남음
- **dev > 추천: > 자동로딩** (4) — 3d남음
- **methodology > 내일까지확정필수** (4) — 2d남음
- **dev > crawling > 올리브영 DOM 2026 > 제품 데이터 추출** (4) — 3d남음
- **dev > 절대 금지: > 과도한리플로우** (4) — 1d남음
- **dev > 추천: > DB구조변경** (4) — 1d남음
- **dev > 절대 금지: > 명령어승인대기시간초과** (4) — 2d남음
- **dev > 추천: > 명령어자동실행** (4) — 2d남음
- **dev > crawling > 올리브영 DOM 2026 > 셀렉터 매핑** (4) — 3d남음
- **methodology > Supervisor통합** (4) — 5d남음
- **dev > 추천: > 베스트프랙티스리서치** (4) — 2d남음
- **dev > trans v19 아키텍처 6페이즈파이프라인 FastAPI서버 WebSocket실시간 > v19혁신 신규추가 > framerate math NTSC분수형프레임스냅 이전없음** (3) — 3d남음
- **dev > 추천: > 폴더별최신파일확인** (3) — 1d남음
- **dev > 추천: > 텔레그램테스트** (3) — 2d남음
- **methodology > 절대 금지: 단편적접근** (3) — 2d남음
- **dev > governance > 절대 금지: > 매직넘버 하드코딩** (3) — 4d남음
- **dev > 추천: > 터미널이용시사용자승인** (3) — 2d남음
- **dev > hijack > CDP** (2) — 7d남음
- **dev > crawling > 올리브영 DOM 2026 > 상세페이지 추출패턴** (2) — 3d남음
- **dev > github docs > 반드시 공리 파생구조 유지** (1) — 6d남음
- **dev > github docs > 반드시 subtitle axiom** (1) — 6d남음
- **dev > github docs > 반드시 독자시스템 솔직분류** (1) — 6d남음
- **dev > github docs > 반드시 벤치마크 결과갱신** (1) — 6d남음
- **dev > github docs > 반드시 EN KO 동기화** (1) — 6d남음
- **dev > github docs > 절대 금지: mkdir beats vector** (1) — 6d남음
- **dev > github docs > 절대 금지: 통계 하드코딩** (1) — 6d남음

### 🎭 ego (2)
- **톤 > 한국어사고 한국어응답** (4) — 5d남음
- **반드시 대화끝정리** (0) — 7d남음

### 🎯 prefrontal (1)
- **roadmap > 의존성 제로 단일바이너리** (4) — 5d남음

### 🔗 shared (0)
(없음)

</details>

## 📊 영역별 현황

| 영역 | 뉴런 | 활성화 | 상세 |
|------|------|--------|------|
| 🛡️ brainstem — 양심/본능 | 18 | 843 | `brainstem/_rules.md` |
| 💓 limbic — 감정 필터 | 0 | 0 | `limbic/_rules.md` |
| 📝 hippocampus — 기록/기억 | 3 | 81 | `hippocampus/_rules.md` |
| 👁️ sensors — 환경 제약 | 7 | 295 | `sensors/_rules.md` |
| 🧠 cortex — 지식/기술 | 154 | 7568 | `cortex/_rules.md` |
| 🎭 ego — 성향/톤 | 2 | 4 | `ego/_rules.md` |
| 🎯 prefrontal — 목표/계획 | 1 | 4 | `prefrontal/_rules.md` |
| 🔗 shared — 공유 지식 | 0 | 0 | `shared/_rules.md` |

