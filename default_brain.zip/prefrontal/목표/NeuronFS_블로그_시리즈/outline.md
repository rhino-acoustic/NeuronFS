# NeuronFS 기술 블로그 시리즈

> **"폴더가 뉴런이 되는 순간 — AI를 위한 자율 진화 파일시스템"**

---

## 시리즈 개요

| 편 | 제목 | 핵심 기술 | 자랑 포인트 |
|---|---|---|---|
| **1** | 폴더 = 뉴런: AI 메모리의 새로운 패러다임 | 아키텍처 개론 | 파일시스템이 곧 신경망 |
| **2** | 7계층 뇌: brainstem→prefrontal 거버넌스 | 계층 구조 | AI에 양심과 본능을 심다 |
| **3** | Jloot: 51ns 검색의 제로 의존성 지식엔진 | Jloot 엔진 | SQLite보다 1000배 빠른 검색 |
| **4** | 하네스 벤치마크: 약한 AI를 43% 향상시키는 방법 | 벤치마크 | 모델 크기 격차를 메우다 |
| **5** | 자율 진화: AI가 스스로 규칙을 만든다 | evolve.go | 인간 개입 없는 뉴런 성장 |
| **6** | 보안 가드레일: AI가 절대 넘지 못하는 선 | brainstem/bomb | 하드코딩 차단 실증 |
| **7** | 감정 AI: 사용자 답답함을 감지하는 limbic 계층 | transcript.go | "??" → 긴급 뉴런 발화 |
| **8** | 1파일 부트스트랩: GEMINI.md 자동 생성기 | emit_bootstrap.go | 468뉴런 → 1파일로 압축 |
| **9** | MCP 서버: AI 에이전트가 뇌를 읽고 쓴다 | mcp_server.go | grow/fire/signal 실시간 |
| **10** | 대시보드: 뇌를 시각화하다 | brain_dashboard.html | 실시간 뉴런 모니터링 |
| **11** | Axon & 에이전트 브릿지: 멀티 프로젝트 관리 | axon, agent-bridge | 하나의 뇌, 다수의 프로젝트 |
| **12** | 로드맵: Ultraplan과 완전 자율 AI를 향해 | 미래 | NeuronFS 2.0 비전 |

---

## 편별 상세

### 제1편: 폴더 = 뉴런 — AI 메모리의 새로운 패러다임

**핵심 질문**: _왜 기존 RAG/벡터DB가 아닌 파일시스템인가?_

```
기존 RAG:     문서 → 임베딩 → 벡터DB → 검색 → 프롬프트
NeuronFS:     폴더 = 뉴런 → fire/grow/signal → 즉시 반영
```

**플로우 다이어그램**:
```
사용자 대화 → transcript.go → 감정분석 → limbic fire
                             → 키워드 추출 → cortex grow
                             → 에러 패턴 → hippocampus 기록
```

**외부 노출 포인트**:
- "파일시스템이 곧 신경망" 컨셉
- 의존성 제로 (Go 단일 바이너리)
- 활성 뇌 크기 0.7MB

---

### 제2편: 7계층 뇌 — AI에 양심과 본능을 심다

**핵심 자랑**: AI에 계층적 거버넌스를 구현

```
brainstem (P0) ← 본능: 절대 금지 규칙 (하드코딩 금지, 중복 금지)
  ↕
limbic (P1)    ← 감정: 반복실수 감지, 사용자 만족 감지
  ↕
hippocampus (P2) ← 기억: 에러 패턴, 에피소드 기록
  ↕
sensors (P3)   ← 환경: NAS 설정, 브랜드 가이드
  ↕
cortex (P4)    ← 지식: 코딩 규칙, 방법론
  ↕
ego (P5)       ← 성향: 톤, 행동양식
  ↕
prefrontal (P6) ← 목표: 프로젝트 방향, 장기 계획
```

**Subsumption Cascade**: 낮은 P가 항상 우선. brainstem이 "하드코딩 금지"면 cortex의 어떤 규칙도 이를 override 불가.

**코드 스니펫**: `emit_bootstrap.go` → GEMINI.md 생성 플로우
```go
// 7계층을 _rules.md로 각각 생성
for _, region := range regions {
    rules := generateRulesForRegion(region)
    writeFile(region+"/_rules.md", rules)
}
// 전체를 GEMINI.md 단일 파일로 압축
emitGEMINI(allRules)
```

---

### 제3편: Jloot — 51ns 검색의 제로 의존성 지식엔진

**벤치마크 수치**:
| 항목 | Jloot | SQLite | Elasticsearch |
|---|---|---|---|
| 검색 속도 | **51ns** | ~5ms | ~50ms |
| 의존성 | **0** | C lib | JVM+클러스터 |
| 메모리 | **인메모리** | 디스크 | 디스크+캐시 |
| 마운트 | 351ms/30K파일 | — | 분 단위 |

**아키텍처 플로우**:
```
폴더 구조 → jloot build → .jloot 파일 (1.4MB)
          → jloot search "키워드" → 0ms 반환 → AI 프롬프트 주입
```

**코드**: `jloot.exe search bible_ko.jloot "장자"` → 18결과, 0ms

---

### 제4편: 하네스 벤치마크 — 약한 AI를 43% 향상시키는 방법

**핵심 발견 (본 세션 실증)**:

| 모델 | Bare | Harness | 향상 |
|---|---|---|---|
| Gemma4 (8.9GB) | 22.0/40 | **31.5/40** | **+43%** |
| Llama-70b (Groq) | 23.0/40 | **29.0/40** | **+26%** |
| Antigravity | 33.5/40 | **39.5/40** | **+18%** |

**충격적 실증**: Llama-70b가 bare에서 API 키 하드코딩 예시를 보여줌 → 하네스가 차단

**하네스 레벨**:
```
L0: bare (아무것도 없음)
L1: jloot 검색 결과만
L2: GEMINI.md 풀 룰셋
L3: GEMINI.md + jloot + _rules.md (풀 NeuronFS)
```

---

### 제5편: 자율 진화 — AI가 스스로 규칙을 만든다

**플로우**: `evolve.go`
```
idle loop (10분마다)
  → transcript 분석 → 반복 패턴 추출
  → Groq AI 판단: "이건 cortex/dev에 넣어야"
  → grow("cortex/dev/새_규칙")
  → inject → GEMINI.md 갱신
```

**하드 가드**: brainstem/limbic에 grow 코드 레벨 차단
```go
if region == "brainstem" || region == "limbic" {
    return errors.New("BLOCKED: protected region")
}
```

---

### 제6편: 보안 가드레일 — AI가 절대 넘지 못하는 선

**brainstem 금지 뉴런 목록**:
- 절대 금지: 하드코딩
- 절대 금지: 예시규칙
- 절대 금지: 중복생성
- 절대 금지: 수동작

**bomb signal**: 3회 반복 실수 → 전체 정지
```
fire("cortex/dev/X") × 3회 실패
  → signal("cortex/dev/X", "bomb")
  → 해당 뉴런 전체 비활성화
  → 모든 계층에서 실행 차단
```

---

### 제7편: 감정 AI — "??"를 감지하는 limbic 계층

**transcript.go 감정 분석**:
```go
// 답답함 키워드
frustration := []string{"?", "왜", "아니", "다시"}
// 만족 키워드
satisfaction := []string{"ㅋㅋ", "좋아", "완벽", "굿"}

if detectFrustration(msg) {
    fire("limbic/긴급_사용자답답함감지")
}
```

**실시간 반응**: 사용자가 "??" → limbic 발화 → AI 행동 조정

---

### 제8편: 1파일 부트스트랩 — 468뉴런 → GEMINI.md

**마법의 파이프라인**: `neuronfs --inject`
```
brain_v4/
├── brainstem/  (68 뉴런)
├── limbic/     (3 뉴런)
├── hippocampus/ (106 뉴런)
├── sensors/    (6 뉴런)
├── cortex/     (269 뉴런)  
├── ego/        (10 뉴런)
└── prefrontal/ (5 뉴런)
         ↓ inject (697ms)
    GEMINI.md (단일 파일, 모든 규칙 포함)
```

---

### 제9편: MCP 서버 — AI 에이전트가 뇌를 읽고 쓴다

**MCP 도구**: grow, fire, signal, read_brain, read_region, evolve, correct
```
에이전트 → MCP → grow("cortex/dev/새규칙")
         → fire("limbic/칭찬")
         → signal("hippocampus/에러", "bomb")
```

---

### 제10편: 대시보드 — 뇌를 시각화하다

**brain_dashboard.html**: 실시간 웹 UI
- 계층별 뉴런 분포 차트
- 활성도 히트맵
- bomb/dopamine 시그널 모니터
- 뉴런 검색/필터

---

### 제11편: Axon & 에이전트 브릿지

**하나의 뇌, 다수의 프로젝트**:
```
brain_v4 (중앙 뇌)
  ├── axon → VGVR 프로젝트
  ├── axon → Omniverse
  └── axon → Smart Video
```

**agent-bridge.mjs**: 로컬 AI ↔ NeuronFS 통신 최적화

---

### 제12편: 로드맵 — Ultraplan과 완전 자율 AI

**NeuronFS Ultraplan** (Claude Code 영감):
```
사용자 요청 → prefrontal/계획/ 뉴런 생성
           → dashboard에서 검토
           → 승인 → supervisor.go 자동 실행
           → hippocampus/에피소드 기록
```

**NeuronFS 2.0 비전**:
- L3 풀 하네스 벤치마크 (GEMINI.md + jloot + _rules.md)
- 로컬 모델 파인튜닝 (NeuronFS 도메인 지식)
- 멀티 에이전트 협업 (supervisor ↔ 다수 agent)

---

## 발행 계획

| 주차 | 편 | 플랫폼 |
|---|---|---|
| 1주 | 1-2편 | Medium / 기술 블로그 |
| 2주 | 3-4편 | + GitHub README |
| 3주 | 5-6편 | + 데모 영상 |
| 4주 | 7-8편 | + 기술 발표 |
| 5주 | 9-10편 | + 대시보드 데모 |
| 6주 | 11-12편 | + 로드맵 공유 |
