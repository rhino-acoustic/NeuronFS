# 🎯 PREFRONTAL — 목표/계획

Active: 1 | Dormant: 34 | Activation: 4

## Axons
- → cortex

## 🔗 Axon 참조 (Attention Residuals)
axon 연결을 통해 관련 영역에서 선택적으로 참조된 뉴런:
- **methodology > 추천: left-side네비게이션** (c:375)
- **methodology > 추천: 프로젝트관리** (c:207)
- **methodology > 추천: 에러분석** (c:151)

## Neurons
- roadmap/
  - **의존성 제로 단일바이너리** (4)

