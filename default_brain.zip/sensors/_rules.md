# 👁️ SENSORS — 환경 제약

Active: 7 | Dormant: 6 | Activation: 295

## Axons
- → brainstem

## 🔗 Axon 참조 (Attention Residuals)
axon 연결을 통해 관련 영역에서 선택적으로 참조된 뉴런:
- **반드시 > 반드시 누락자문** (c:25)
- **절대 금지: 뇌 직접수정 MCP필수** (c:1)
- **반드시 > 반드시 빌드경로 SSOT** (c:0)

## Neurons
- 이벤트/
  - 절대 **장소검토** (200)
  - 절대 **장소검색규칙** (54)
  - 절대 **장소조건** (28)
  - **장소검토의중요성** (4)
  - **장소검색시교통접근성考慮** (3)
  - **장소확정기한** (3)
- 환경/
  - **Supabase EdgeFunctions** (3)

