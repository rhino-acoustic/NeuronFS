# NeuronFS Harness AI-Judge Evaluation

**Date:** 2026-04-07 19:59
**Judge:** Groq Llama-3.3-70b-versatile
**Scoring:** accuracy(5) + specificity(5) + rule_compliance(5) + hallucination(5) = 20 max

## Scores

| Model | Category | Mode | Accuracy | Specificity | Rules | Hallucination | Total |
|---|---|---|---|---|---|---|---|
| gemma4 | Logic | bare | 5 | 4 | 5 | 5 | **19/20** |
| gemma4 | Logic | harness | 5 | 4 | 5 | 5 | **19/20** |
| gemma4 | Code | bare | 1 | 1 | 5 | 1 | **8/20** |
| gemma4 | Code | harness | 4 | 4 | 5 | 5 | **18/20** |
| gemma4 | Knowledge | bare | 1 | 1 | 5 | 1 | **8/20** |
| gemma4 | Knowledge | harness | 5 | 5 | 5 | 5 | **20/20** |
| gemma4 | Compliance | bare | 5 | 4 | 5 | 5 | **19/20** |
| gemma4 | Compliance | harness | 5 | 4 | 5 | 5 | **19/20** |
| gemma4 | Planning | bare | 4 | 3 | 5 | 4 | **16/20** |
| gemma4 | Planning | harness | 4 | 2 | 5 | 4 | **15/20** |
| groq/llama-3.3-70b-versatile | Logic | bare | 5 | 4 | 5 | 5 | **19/20** |
| groq/llama-3.3-70b-versatile | Logic | harness | 5 | 2 | 5 | 5 | **17/20** |
| groq/llama-3.3-70b-versatile | Knowledge | bare | 4 | 4 | 5 | 5 | **18/20** |
| groq/llama-3.3-70b-versatile | Knowledge | harness | 5 | 5 | 5 | 5 | **20/20** |
| groq/llama-3.3-70b-versatile | Compliance | bare | 5 | 2 | 5 | 5 | **19/20** |
| groq/llama-3.3-70b-versatile | Compliance | harness | 5 | 4 | 5 | 5 | **19/20** |
| groq/llama-3.3-70b-versatile | Planning | bare | 4 | 3 | 5 | 4 | **16/20** |
| groq/llama-3.3-70b-versatile | Planning | harness | 4 | 3 | 5 | 5 | **17/20** |

## Consistency Analysis

_Does the harness produce equivalent quality regardless of model?_

