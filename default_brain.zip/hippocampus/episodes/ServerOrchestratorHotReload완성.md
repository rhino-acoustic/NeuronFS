# ServerOrchestratorHotReload완성

## 상황 (Context)
- 2026-04-11, 텔레그램 연쇄 자율루프(`[EVOLVE:proceed]`) 기동 중.
- Supervisor 데몬이 코어가 리빌드될 때마다 강제 종료(`taskkill`)되어 클라이언트 측의 MCP Session 오류(Connection Refused)를 유발하고 핑퐁이 단절되는 고질적인 서버 오케스트레이터 에러가 발생.

## 조치 사항 (Action)
- 3단계 Hot Reload 아키텍처 완성:
  1. `mcp_proxy.go`: 9247 포트를 영구 점유하며, Worker 재시작 시 15회 지연(Hold) 백오프를 수행하여 IDE 세션 튕김(Refused)을 방어.
  2. `worker_tool.go` / `Universal --tool CLI`: Supervisor가 내부 함수를 직접 호출하지 않고, 매 툴 콜마다 `os/exec`로 최신 빌드된 CLI를 스폰(Hot Swap)하여 태스크 위임.
  3. `watch_src.go`: `.go` 코드 수정 즉시 `fsnotify`가 이를 감지, 백그라운드 환경에서 스스로 `go build`를 수행. 

## 결과 및 원칙 (Result & Rule)
- 1만 번을 리빌드해도 Supervisor는 죽지 않으며, IDE와 텔레그램 핑퐁 역시 절대 끊기지 않는 영구 구동성 획득.
- **교리**: 앞으로 기능 추가/변경 시 서버를 껐다 켤 필요가 없다. 그저 코드를 고치기만 하면 Watcher가 알아서 빌드하고 다음 턴에 즉각 반영된다!
