# 📝 HIPPOCAMPUS — 기록/기억

Active: 3 | Dormant: 8 | Activation: 81

## Axons
- → brainstem
- → cortex

## 🔗 Axon 참조 (Attention Residuals)
axon 연결을 통해 관련 영역에서 선택적으로 참조된 뉴런:
- **methodology > 추천: left-side네비게이션** (c:375)
- **methodology > 추천: 프로젝트관리** (c:207)
- **methodology > 추천: 에러분석** (c:151)

## Neurons
- 에러 패턴/
  - 절대 **SPA루팅에러** (26)
  - **서버오케스트레이터에러** (4)
- 에피소드/
  - 절대 **emit bootstrap 로그스케일 적용** (51)

